const config = require('flarum-webpack-config')({
  useExtensions: ['fof-follow-tags', 'fof-user-directory']
});

module.exports = config;
