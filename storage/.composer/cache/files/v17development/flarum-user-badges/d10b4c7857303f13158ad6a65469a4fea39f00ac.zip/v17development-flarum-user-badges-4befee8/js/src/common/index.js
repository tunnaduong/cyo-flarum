import app from 'flarum/common/app';

app.initializers.add('v17development/flarum-user-badges', () => {
  // console.log('[v17development/flarum-user-badges] Hello, forum and admin!')
});
