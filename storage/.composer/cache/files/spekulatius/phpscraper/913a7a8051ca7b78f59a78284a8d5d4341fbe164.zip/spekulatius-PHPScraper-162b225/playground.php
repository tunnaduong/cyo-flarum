<?php

require __DIR__ . '/vendor/autoload.php';

echo "\n";
echo "#########################\n";
echo "# PHPScraper Playground #\n";
echo "#########################\n";
echo "\n";
echo "# Here you can try out your code or examples from phpscraper.de\n";
echo "\n";

$web = new \Spekulatius\PHPScraper\PHPScraper;
