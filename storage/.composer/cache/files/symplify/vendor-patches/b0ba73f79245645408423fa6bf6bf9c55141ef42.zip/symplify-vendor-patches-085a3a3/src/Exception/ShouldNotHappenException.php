<?php

declare (strict_types=1);
namespace Symplify\VendorPatches\Exception;

use Exception;
final class ShouldNotHappenException extends Exception
{
}
