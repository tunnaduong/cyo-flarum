/// <reference types="mithril" />
import ExtensionPage from 'flarum/admin/components/ExtensionPage';
export default class StatisticsPage extends ExtensionPage {
    content(): JSX.Element;
}
