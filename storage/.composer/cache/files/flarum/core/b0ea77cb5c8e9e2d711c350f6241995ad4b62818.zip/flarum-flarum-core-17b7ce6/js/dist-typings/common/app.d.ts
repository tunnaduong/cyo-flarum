import type Application from './Application';
/**
 * The instance of Application within the common namespace.
 */
declare const _default: Application;
export default _default;
