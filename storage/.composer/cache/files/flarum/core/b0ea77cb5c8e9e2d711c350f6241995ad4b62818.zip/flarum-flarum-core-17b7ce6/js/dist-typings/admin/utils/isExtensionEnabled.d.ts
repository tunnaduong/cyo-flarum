export default function isExtensionEnabled(name: any): any;
