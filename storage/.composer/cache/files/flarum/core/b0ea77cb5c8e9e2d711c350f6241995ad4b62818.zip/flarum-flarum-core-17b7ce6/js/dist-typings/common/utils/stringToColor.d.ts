/**
 * Convert the given string to a unique color.
 */
export default function stringToColor(string: string): string;
