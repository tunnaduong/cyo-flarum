import Forum from './ForumApplication';
declare const app: Forum;
export default app;
