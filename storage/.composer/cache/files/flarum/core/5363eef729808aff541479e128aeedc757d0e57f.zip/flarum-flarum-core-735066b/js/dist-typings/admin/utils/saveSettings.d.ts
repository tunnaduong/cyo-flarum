export default function saveSettings(settings: any): Promise<any>;
