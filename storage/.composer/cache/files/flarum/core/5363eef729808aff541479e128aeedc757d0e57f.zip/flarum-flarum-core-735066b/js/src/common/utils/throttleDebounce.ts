// Re-exports `throttle-debounce` to be used in `compat.js`.

export { throttle, debounce } from 'throttle-debounce';
