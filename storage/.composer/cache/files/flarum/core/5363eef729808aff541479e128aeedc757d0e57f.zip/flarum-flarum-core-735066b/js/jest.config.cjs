module.exports = require('@flarum/jest-config')({});
