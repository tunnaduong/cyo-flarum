/**
 * The `liveHumanTimes` initializer sets up a loop every 1 second to update
 * timestamps rendered with the `humanTime` helper.
 */
export default function liveHumanTimes(): void;
