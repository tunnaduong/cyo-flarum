/**
 * Displays information about a the first or last post in a discussion.
 *
 * ### Attrs
 *
 * - `discussion`
 * - `lastPost`
 */
export default class TerminalPost extends Component<import("../../common/Component").ComponentAttrs, undefined> {
    constructor();
    view(): JSX.Element;
}
import Component from "../../common/Component";
