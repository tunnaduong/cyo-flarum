export default function textContrastClass(hexcolor: string | null | undefined): string;
