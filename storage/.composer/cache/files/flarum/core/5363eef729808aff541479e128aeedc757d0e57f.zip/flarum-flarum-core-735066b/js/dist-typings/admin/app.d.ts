import Admin from './AdminApplication';
declare const app: Admin;
export default app;
