import Tag from '../models/Tag';
export default function sortTags(tags: Tag[]): Tag[];
