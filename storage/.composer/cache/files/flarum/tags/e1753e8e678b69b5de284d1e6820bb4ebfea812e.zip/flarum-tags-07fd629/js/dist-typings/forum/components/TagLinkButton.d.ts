export default class TagLinkButton extends LinkButton {
    static initAttrs(attrs: any): void;
    view(vnode: any): JSX.Element;
}
import LinkButton from "flarum/common/components/LinkButton";
