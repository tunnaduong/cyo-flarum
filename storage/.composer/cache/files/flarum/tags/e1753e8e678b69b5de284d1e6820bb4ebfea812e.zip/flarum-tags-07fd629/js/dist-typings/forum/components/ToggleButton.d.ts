/**
 * @TODO move to core
 */
export default class ToggleButton extends Component<import("flarum/common/Component").ComponentAttrs, undefined> {
    constructor();
    view(vnode: any): JSX.Element;
}
import Component from "flarum/common/Component";
