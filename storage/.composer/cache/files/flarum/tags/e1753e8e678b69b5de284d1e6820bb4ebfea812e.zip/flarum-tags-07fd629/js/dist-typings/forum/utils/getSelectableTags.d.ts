export default function getSelectableTags(discussion: any): any;
