export default function jumpToQueue(): void;
