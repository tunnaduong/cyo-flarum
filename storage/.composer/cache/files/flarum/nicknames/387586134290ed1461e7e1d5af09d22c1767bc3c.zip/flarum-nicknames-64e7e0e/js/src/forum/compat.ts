import NicknameModal from './components/NicknameModal';

export default {
  'nicknames/components/NicknameModal': NicknameModal,
};
