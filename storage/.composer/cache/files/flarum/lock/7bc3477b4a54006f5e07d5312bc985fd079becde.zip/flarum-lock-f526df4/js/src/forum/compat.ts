import DiscussionLockedNotification from './components/DiscussionLockedNotification';
import DiscussionLockedPost from './components/DiscussionLockedPost';

export default {
  'lock/components/DiscussionLockedNotification': DiscussionLockedNotification,
  'lock/components/DiscussionLockedPost': DiscussionLockedPost,
};
