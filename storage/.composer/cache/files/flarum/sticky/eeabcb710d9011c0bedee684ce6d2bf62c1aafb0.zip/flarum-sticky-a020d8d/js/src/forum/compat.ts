import DiscussionStickiedPost from './components/DiscussionStickiedPost';

export default {
  'sticky/components/DiscussionStickiedPost': DiscussionStickiedPost,
};
