import commonCompat from '../common/compat';

export default {
  ...commonCompat,
};
