export default function insertAfter(newNode: HTMLElement, referenceNode: Element): HTMLElement | undefined;
