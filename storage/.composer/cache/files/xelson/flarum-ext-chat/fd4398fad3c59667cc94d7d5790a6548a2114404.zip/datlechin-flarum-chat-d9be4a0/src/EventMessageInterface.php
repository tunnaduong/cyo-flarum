<?php

namespace Xelson\Chat;

interface EventMessageInterface
{
    public function content(): string;
}
